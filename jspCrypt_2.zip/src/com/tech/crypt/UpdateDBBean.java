package com.tech.crypt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tech.crypt.work.BCrypt;
import com.tech.crypt.work.SHA256;

public class UpdateDBBean {
	private static UpdateDBBean instance=new UpdateDBBean();
	public static UpdateDBBean getInstance() {
		return instance;
	}
	public UpdateDBBean() {
		// TODO Auto-generated constructor stub
	}
	
	//db에 Connection객체 생성하는 메소드
	private Connection getConnection() throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
//		접속
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String user="hr";
		String pw="123456";
		Connection con=DriverManager.getConnection(url,user,pw);

		return con;
	}
	
	//member5테이블의 내용을 조회,cryptProcessList.jsp에서 사용
	public List<UpdateDataBean> getMembers(){
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		List<UpdateDataBean> memberList=null;
		
		
		int x=0;
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement("select count(*) from member5");
			rs=pstmt.executeQuery();
			
			if(rs.next())
				x=rs.getInt(1);
			
			
			pstmt=conn.prepareStatement("select id,pwd from member5");
			rs=pstmt.executeQuery();
			
			if(rs.next()) {
				memberList=new ArrayList<UpdateDataBean>();
				do {
					UpdateDataBean member=new UpdateDataBean();
					member.setId(rs.getString("id"));
					member.setPwd(rs.getString("pwd"));
					memberList.add(member);
				}while(rs.next());
			}	
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null)	try {rs.close();} catch (SQLException ex) {	}
			if (pstmt != null)try {	pstmt.close();	} catch (SQLException ex) {	}
			if (conn != null)	try {conn.close();} catch (SQLException ex) {	}
		}
		
		return memberList;
	}
	
	public void updateMember() {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		SHA256 sha=SHA256.getInsatnce();
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement("select id,pwd from member5");
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				String id=rs.getString("id");
				String orgPass=rs.getString("pwd");
				
				//원래의 비밀번호를 sha256이용해서 암호화
				String shaPass=sha.getSha256(orgPass.getBytes());
				System.out.println("shpw : "+shaPass);
				
				//shaPass를 BCrypt.gensalt()를 통해서 salt난수를 이용해 hashpw 암호화
				String bcPass=BCrypt.hashpw(shaPass, BCrypt.gensalt());
				System.out.println("bcCrypt : "+bcPass);	
				
				pstmt=conn.prepareStatement("update member5 set pwd=? where id=?");
				pstmt.setString(1, bcPass);
				pstmt.setString(2, id);
				
				pstmt.executeUpdate();//실행
				
				
			}
						
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException ex) {
				}
		}	
	}
}

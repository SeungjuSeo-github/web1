package com.tech.controll.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tech.controll.disp.Controller;
import com.tech.crypt.work.BCrypt;
import com.tech.crypt.work.SHA256;
import com.tech.db.DBcon;

public class LoginProcController  implements Controller{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("LoginProcController");
		
//		db접속
		Connection con=DBcon.getConnection();
		
		String id=request.getParameter("id");
		String pw=request.getParameter("pw");
		
		System.out.println("id"+id);
		String sql="select id,pwd,shpwd,bcpwd from member5 where id=?";
		
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, id);
		
		ResultSet rs=pstmt.executeQuery();
		
//		if (rs.next()) {
//			System.out.println(rs.getString(1)+":"+rs.getString(2));
//			
//		}
		
		SHA256 sha=SHA256.getInsatnce();
		String shaPass=sha.getSha256(pw.getBytes());
		Boolean idpwdboolean=false;
		if(rs.next()) {
			idpwdboolean=BCrypt.checkpw(shaPass, rs.getString("bcpwd"));
		}
//		성공여부확인
		System.out.println("성공여부 : "+idpwdboolean);
		
		if (idpwdboolean) {
			request.getSession().setAttribute("uid", id);
		}
		
		response.sendRedirect("../index.jsp");
		
		
	}

}

package com.tech.controll.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tech.controll.disp.Controller;

public class MemberJoinController implements Controller{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) 
			throws Exception{
		System.out.println("MemberJoinController");
		
		response.sendRedirect("joinform.jsp");
		
	}

}

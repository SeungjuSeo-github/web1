package com.tech.controll.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tech.controll.disp.Controller;
import com.tech.crypt.work.BCrypt;
import com.tech.crypt.work.SHA256;
import com.tech.db.DBcon;

public class MemberJoinProcController implements Controller{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) 
			throws Exception{
		System.out.println("MemberJoinProcController");
		//db에 회원정보 insert
		Connection con=DBcon.getConnection();
	
		String id=request.getParameter("id");
		String pwd=request.getParameter("pw");
		String name=request.getParameter("name");
		String addr=request.getParameter("addr");

		SHA256 sha=SHA256.getInsatnce();
//		String shPwd="F6E0A1E2AC41945A9AA7FF8A8AAA0CEBC12A3BCC981A929AD5CF810A090E11AE";
//		String bcPwd=BCrypt.hashpw(shPwd, BCrypt.gensalt());
		
//		System.out.println("인증확인1 : "+BCrypt.checkpw(shPwd, bcPwd));
//		System.out.println("인증확인2 : "+BCrypt.checkpw("F6E0A1E2AC41945", bcPwd));
		
		String shPwd=sha.getSha256(pwd.getBytes());
//		
		String bcPwd=BCrypt.hashpw(shPwd, BCrypt.gensalt());
//		
		String sql="insert into member5(id,pwd,shpwd,bcpwd) values(?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.setString(2, pwd);
		pstmt.setString(3, shPwd);
		pstmt.setString(4, bcPwd);
		
		pstmt.executeUpdate();
		
		response.sendRedirect("../index.jsp");
		
	}

}

package com.tech.controll.disp;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.java.browser.dom.DOMService;
import com.tech.controll.controllers.LogOutProcController;
import com.tech.controll.controllers.LoginController;
import com.tech.controll.controllers.LoginProcController;
import com.tech.controll.controllers.MemberJoinController;
import com.tech.controll.controllers.MemberJoinProcController;

public class MemDispatcher extends HttpServlet{
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		String requestUri=request.getRequestURI();
		String conPath=request.getContextPath();
		
		String com=requestUri.substring(conPath.length());
		
		System.out.println("com : "+com);
		Controller controller=null;
		
		try {
			if (com.equals("/join/memberjoin.do")) {
				controller=new MemberJoinController();
			}else if (com.equals("/join/memberjoinproc.do")) {
				controller=new MemberJoinProcController();
			}else if (com.equals("/login/loginproc.do")) {
				controller=new LoginProcController();
			}else if (com.equals("/join/logoutproc.do")) {
				controller=new LogOutProcController();
			}else if (com.equals("/login/login.do")) {
				controller=new LoginController();
			}
			
			
			controller.execute(request, response);
			
		} catch (Exception e) {
			// TODO: handle exception
		}	
	}

	/*@Override -- 로그인폼에 겟인지 폼인지 구분
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("dopost신호");
		
	}
	
	@Override
		protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("doget신호");
	}*/
	

}
